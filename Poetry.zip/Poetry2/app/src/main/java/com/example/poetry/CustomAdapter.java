package com.example.poetry;


import android.graphics.Color;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomHolder>
{
    List <String> datarecv= new ArrayList<> (  );
    public CustomAdapter(List<String> datarecv) {
        this.datarecv = datarecv;
    }




    @NonNull

    @Override

    public CustomHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {
        View view = LayoutInflater.from ( viewGroup.getContext () ).inflate ( R.layout.item_list,viewGroup,false );

        return new CustomHolder ( view );
    }

    @Override
    public void onBindViewHolder(@NonNull CustomHolder customHolder, int i)
    {
        String data= datarecv.get ( i );
        customHolder.textView.setText ( data );
        String []colors={"#0e59d1","#d10ea9","#8e0b8e","#5b8e0b","#8e5d0b"};
        int color=i%colors.length;
        int intcolor= Color.parseColor ( colors[color] );

        customHolder.linearLayout.setBackgroundColor ( intcolor );




    }

    @Override
    public int getItemCount() {
        return datarecv.size ();
    }

    class CustomHolder extends RecyclerView.ViewHolder {

        TextView textView;

        LinearLayout linearLayout;
        public CustomHolder(@NonNull View itemView)

        {
            super ( itemView );
            textView= (TextView)itemView.findViewById ( R.id.poetry );
            linearLayout=(LinearLayout)itemView.findViewById ( R.id.backgroudcolor );
        }
    }
}
