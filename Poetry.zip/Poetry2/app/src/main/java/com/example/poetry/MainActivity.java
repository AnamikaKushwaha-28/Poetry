package com.example.poetry;


import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        recyclerView=(RecyclerView)findViewById ( R.id.recyclerview );
        recyclerView.setLayoutManager ( new LinearLayoutManager ( this ) );
        customAdapter=new CustomAdapter ( QuoteList () );
        recyclerView.setAdapter ( customAdapter );
    }

    private List<String> QuoteList()
    {
        List<String> quotes= new ArrayList<String> (  );
        BufferedReader bufferedReader=null;
        ArrayList<String> items= new ArrayList<String>();

        try {
            bufferedReader =new BufferedReader ( new InputStreamReader ( this.getAssets ().open ( "q.txt" ),"UTF-8" ) );
            String lines="";

            while ((lines=bufferedReader.readLine ())!=null)
            {

                quotes.add  (lines ) ;



            }
        }
        catch (IOException a)
        {
            a.printStackTrace ();
        }
        finally {
            if(bufferedReader!=null)
            {
                try {
                    bufferedReader.close ();
                }
                catch (IOException a)
                {
                    a.printStackTrace ();
                }

            }

        }
        return quotes;
    }



}